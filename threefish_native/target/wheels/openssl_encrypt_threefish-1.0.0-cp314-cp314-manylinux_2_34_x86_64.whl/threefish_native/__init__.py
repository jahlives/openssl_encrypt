from .threefish_native import *

__doc__ = threefish_native.__doc__
if hasattr(threefish_native, "__all__"):
    __all__ = threefish_native.__all__